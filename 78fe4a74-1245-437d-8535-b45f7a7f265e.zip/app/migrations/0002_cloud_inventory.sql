-- Per-account cloud snapshot and append-only deletion history.
CREATE TABLE IF NOT EXISTS inventory_snapshots (
  user_id TEXT PRIMARY KEY,
  snapshot_json TEXT NOT NULL,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS inventory_deletion_audit (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL,
  record_type TEXT NOT NULL,
  record_id TEXT NOT NULL,
  record_name TEXT NOT NULL,
  reason TEXT NOT NULL DEFAULT '',
  deleted_at TEXT NOT NULL,
  source TEXT NOT NULL DEFAULT 'offline',
  record_json TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_inventory_audit_user_date
  ON inventory_deletion_audit(user_id, deleted_at DESC);
