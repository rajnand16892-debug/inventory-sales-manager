import { bindings } from '@/lib/bindings.server'

export const SESSION_COOKIE = 'inventory_plus_session'
const SESSION_SECONDS = 60 * 60 * 24 * 30
const encoder = new TextEncoder()

function bytesToHex(bytes: Uint8Array) { return Array.from(bytes, byte => byte.toString(16).padStart(2, '0')).join('') }
function hexToBytes(hex: string) { return new Uint8Array(hex.match(/.{1,2}/g)?.map(byte => parseInt(byte, 16)) ?? []) }
async function sha256(value: string) { return bytesToHex(new Uint8Array(await crypto.subtle.digest('SHA-256', encoder.encode(value)))) }
async function passwordHash(password: string, saltHex: string) {
  const key = await crypto.subtle.importKey('raw', encoder.encode(password), 'PBKDF2', false, ['deriveBits'])
  const bits = await crypto.subtle.deriveBits({ name: 'PBKDF2', hash: 'SHA-256', salt: hexToBytes(saltHex), iterations: 100000 }, key, 256)
  return bytesToHex(new Uint8Array(bits))
}
export function cookieValue(request: Request, name = SESSION_COOKIE) {
  const raw = request.headers.get('cookie') ?? ''
  for (const part of raw.split(';')) { const [key, ...rest] = part.trim().split('='); if (key === name) return rest.join('=') }
  return null
}
export function sessionCookie(token: string, maxAge = SESSION_SECONDS) {
  return `${SESSION_COOKIE}=${token}; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=${maxAge}`
}
export async function currentAppUser(request: Request) {
  const token = cookieValue(request)
  const db = bindings().DB
  if (!token || !db) return null
  try {
    const tokenHash = await sha256(token)
    const row = await db.prepare('SELECT u.id, u.name, u.email, s.expires_at FROM app_sessions s JOIN app_users u ON u.id = s.user_id WHERE s.token_hash = ?').bind(tokenHash).first<{id:string;name:string;email:string;expires_at:number}>()
    if (!row || row.expires_at <= Math.floor(Date.now() / 1000)) {
      if (row) await db.prepare('DELETE FROM app_sessions WHERE token_hash = ?').bind(tokenHash).run()
      return null
    }
    return { id: row.id, name: row.name, email: row.email }
  } catch { return null }
}
export async function registerAccount(name: string, email: string, password: string) {
  const db = bindings().DB
  if (!db) throw new Error('database_unavailable')
  const id = crypto.randomUUID()
  const salt = bytesToHex(crypto.getRandomValues(new Uint8Array(16)))
  const hash = await passwordHash(password, salt)
  await db.prepare('INSERT INTO app_users (id, name, email, password_salt, password_hash) VALUES (?, ?, ?, ?, ?)').bind(id, name, email, salt, hash).run()
  return { id, name, email }
}
export async function loginAccount(email: string, password: string) {
  const db = bindings().DB
  if (!db) throw new Error('database_unavailable')
  const row = await db.prepare('SELECT id, name, email, password_salt, password_hash FROM app_users WHERE email = ?').bind(email).first<{id:string;name:string;email:string;password_salt:string;password_hash:string}>()
  if (!row) return null
  const supplied = await passwordHash(password, row.password_salt)
  const a = encoder.encode(supplied), b = encoder.encode(row.password_hash)
  let diff = a.length ^ b.length
  for (let i = 0; i < Math.max(a.length, b.length); i++) diff |= (a[i] ?? 0) ^ (b[i] ?? 0)
  return diff === 0 ? { id: row.id, name: row.name, email: row.email } : null
}
export async function createSession(userId: string) {
  const db = bindings().DB
  if (!db) throw new Error('database_unavailable')
  const token = bytesToHex(crypto.getRandomValues(new Uint8Array(32)))
  const tokenHash = await sha256(token)
  const expiresAt = Math.floor(Date.now() / 1000) + SESSION_SECONDS
  await db.prepare('INSERT INTO app_sessions (token_hash, user_id, expires_at) VALUES (?, ?, ?)').bind(tokenHash, userId, expiresAt).run()
  return token
}
export async function revokeSession(request: Request) {
  const token = cookieValue(request)
  const db = bindings().DB
  if (!token || !db) return
  await db.prepare('DELETE FROM app_sessions WHERE token_hash = ?').bind(await sha256(token)).run()
}
