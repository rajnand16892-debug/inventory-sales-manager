import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useRef, useState } from "react";

export const Route = createFileRoute("/")({ component: Index });

type Product = { id: string; sku: string; name: string; category: string; qty: number; unit: string; cost: number; price: number; reorder: number };
type Sale = { id: string; invoice: string; customer: string; date: string; amount: number; method: string; status: string; productId?: string; productName?: string; qty?: number; unit?: string; cancelReason?: string; cancelledAt?: string };
type Contact = { id: string; name: string; phone: string; kind: "ग्राहक" | "सप्लायर" };
type Purchase = { id: string; product: string; qty: number; unit: string; supplier: string; cost: number; total: number; date: string };
type DeletionRecord = { id: string; recordType: string; recordId: string; recordName: string; reason: string; deletedAt: string; source: string; recordData: unknown };
type Section = "dashboard" | "products" | "sales" | "purchases" | "customers" | "suppliers" | "reports" | "settings";
const initialProducts: Product[] = [];
const initialSales: Sale[] = [];
const money = (n: number) => new Intl.NumberFormat("en-IN", { style: "currency", currency: "INR", maximumFractionDigits: 0 }).format(n);

function Index() {
  const [section, setSection] = useState<Section>("dashboard");
  const [products, setProducts] = useState<Product[]>(initialProducts);
  const [sales, setSales] = useState<Sale[]>(initialSales);
  const [contacts, setContacts] = useState<Contact[]>([]);
  const [purchases, setPurchases] = useState<Purchase[]>([]);
  const [deletedRecords, setDeletedRecords] = useState<DeletionRecord[]>([]);
  const [cloudStatus, setCloudStatus] = useState("जाँच हो रही है");
  const [cloudReady, setCloudReady] = useState(false);
  const [cloudUser, setCloudUser] = useState<Record<string, unknown> | null>(null);
  const cloudInitRef = useRef(false);
  const [search, setSearch] = useState("");
  const [selectedProductIds, setSelectedProductIds] = useState<string[]>([]);
  const [modal, setModal] = useState<"product" | "sale" | "purchase" | "account" | null>(null);
  const [accountMode, setAccountMode] = useState<"login" | "register">("login");
  const [accountForm, setAccountForm] = useState({ name: "", email: "", password: "" });
  const [accountBusy, setAccountBusy] = useState(false);
  const [accountError, setAccountError] = useState("");
  const [notice, setNotice] = useState("");
  const [online, setOnline] = useState(true);
  const [loaded, setLoaded] = useState(false);
  const [installPrompt, setInstallPrompt] = useState<any>(null);
  const [purchaseForm, setPurchaseForm] = useState({ productId: "", qty: "1", supplier: "", cost: "0" });
  const [importSummary, setImportSummary] = useState("");
  const [productForm, setProductForm] = useState({ name: "", sku: "", category: "", qty: "0", unit: "पीस", cost: "0", price: "0", reorder: "5" });
  const [saleForm, setSaleForm] = useState({ customer: "", productId: "", qty: "1", method: "UPI" });
  useEffect(() => {
    try {
      const p = localStorage.getItem("ims-products-v1");
      const s = localStorage.getItem("ims-sales-v1");
      const c = localStorage.getItem("ims-contacts-v1");
      const b = localStorage.getItem("ims-purchases-v1");
      const d = localStorage.getItem("ims-deleted-v1");
      if (c) setContacts(JSON.parse(c));
      if (b) setPurchases(JSON.parse(b));
      if (d) setDeletedRecords(JSON.parse(d));
      if (p) {
        const savedProducts = JSON.parse(p) as Product[];
        const demoNames = ["A4 कॉपी पेपर", "बॉल पेन नीला", "USB केबल 1m", "पैकिंग टेप", "कैलकुलेटर"];
        const isDemo = savedProducts.length === 5 && savedProducts.every((item, i) => item.id === `p${i+1}` && item.name === demoNames[i]);
        if (isDemo) { localStorage.removeItem("ims-products-v1"); localStorage.removeItem("ims-sales-v1"); }
        else setProducts(savedProducts);
      }
      if (s && !localStorage.getItem("ims-products-v1") && !localStorage.getItem("ims-sales-v1")) { /* old sample data was cleared */ }
      else if (s) {
        const savedSales = JSON.parse(s) as Sale[];
        if (!savedSales.every(item => ["s1", "s2", "s3", "s4"].includes(item.id))) setSales(savedSales);
      }
    } catch { /* Keep the starter ledger if browser storage is unavailable. */ }
    setOnline(navigator.onLine);
    const on = () => setOnline(true); const off = () => setOnline(false);
    const install = (e: Event) => { e.preventDefault(); setInstallPrompt(e); };
    window.addEventListener("beforeinstallprompt", install as EventListener);
    if ("serviceWorker" in navigator) navigator.serviceWorker.register("/sw.js").catch(() => {});
    window.addEventListener("online", on); window.addEventListener("offline", off);
    setLoaded(true);
    return () => { window.removeEventListener("online", on); window.removeEventListener("offline", off); window.removeEventListener("beforeinstallprompt", install as EventListener); };
  }, []);
  useEffect(() => { if (loaded) { try { localStorage.setItem("ims-products-v1", JSON.stringify(products)); } catch {} } }, [products, loaded]);
  useEffect(() => { if (loaded) { try { localStorage.setItem("ims-sales-v1", JSON.stringify(sales)); } catch {} } }, [sales, loaded]);
  useEffect(() => { if (loaded) { try { localStorage.setItem("ims-contacts-v1", JSON.stringify(contacts)); } catch {} } }, [contacts, loaded]);
  useEffect(() => { if (loaded) { try { localStorage.setItem("ims-purchases-v1", JSON.stringify(purchases)); } catch {} } }, [purchases, loaded]);
  useEffect(() => { if (loaded) { try { localStorage.setItem("ims-deleted-v1", JSON.stringify(deletedRecords)); } catch {} } }, [deletedRecords, loaded]);
  useEffect(() => {
    if (!loaded || !online || cloudInitRef.current) return;
    cloudInitRef.current = true;
    void (async () => {
      try {
        const authResponse = await fetch("/api/user", { credentials: "include", cache: "no-store" });
        if (authResponse.status === 401) { setCloudStatus("साइन इन ज़रूरी"); return; }
        if (!authResponse.ok) { setCloudStatus("क्लाउड उपलब्ध नहीं"); return; }
        const profile = await authResponse.json() as Record<string, unknown>;
        const response = await fetch("/api/inventory", { credentials: "include", cache: "no-store" });
        if (!response.ok) { setCloudStatus(response.status === 401 ? "साइन इन ज़रूरी" : "क्लाउड उपलब्ध नहीं"); return; }
        setCloudUser(profile);
        const remote = await response.json() as { snapshot: { products?: Product[]; sales?: Sale[]; contacts?: Contact[]; purchases?: Purchase[] } | null; audit?: DeletionRecord[] };
        const localSnapshot = {
          products: JSON.parse(localStorage.getItem("ims-products-v1") || "[]") as Product[],
          sales: JSON.parse(localStorage.getItem("ims-sales-v1") || "[]") as Sale[],
          contacts: JSON.parse(localStorage.getItem("ims-contacts-v1") || "[]") as Contact[],
          purchases: JSON.parse(localStorage.getItem("ims-purchases-v1") || "[]") as Purchase[],
        };
        const localAudit = JSON.parse(localStorage.getItem("ims-deleted-v1") || "[]") as DeletionRecord[];
        const previousCloudUserId = localStorage.getItem("ims-cloud-user-v1");
        const isDifferentAccount = Boolean(previousCloudUserId && previousCloudUserId !== String(profile.id ?? ""));
        if (isDifferentAccount && !remote.snapshot) {
          setProducts([]); setSales([]); setContacts([]); setPurchases([]); setDeletedRecords([]);
          const emptySnapshot = { products: [], sales: [], contacts: [], purchases: [] };
          const emptyResponse = await fetch("/api/inventory", { method: "POST", credentials: "include", headers: { "content-type": "application/json" }, body: JSON.stringify({ snapshot: emptySnapshot, audit: [] }) });
          if (!emptyResponse.ok) { setCloudStatus("क्लाउड सेव नहीं हुआ"); return; }
        } else if (remote.snapshot) {
          setProducts(Array.isArray(remote.snapshot.products) ? remote.snapshot.products : []);
          setSales(Array.isArray(remote.snapshot.sales) ? remote.snapshot.sales : []);
          setContacts(Array.isArray(remote.snapshot.contacts) ? remote.snapshot.contacts : []);
          setPurchases(Array.isArray(remote.snapshot.purchases) ? remote.snapshot.purchases : []);
          const auditMap = new Map<string, DeletionRecord>();
          [...(remote.audit || []), ...localAudit].forEach(item => auditMap.set(item.id, item));
          const mergedAudit = [...auditMap.values()];
          setDeletedRecords(mergedAudit.sort((a,b) => b.deletedAt.localeCompare(a.deletedAt)));
        } else {
          const initialResponse = await fetch("/api/inventory", { method: "POST", credentials: "include", headers: { "content-type": "application/json" }, body: JSON.stringify({ snapshot: localSnapshot, audit: localAudit }) });
          if (!initialResponse.ok) { setCloudStatus("क्लाउड सेव नहीं हुआ"); return; }
        }
        localStorage.setItem("ims-cloud-user-v1", String(profile.id ?? ""));
        setCloudReady(true);
        setCloudStatus("क्लाउड सिंक सक्रिय");
      } catch { setCloudStatus("क्लाउड सिंक लंबित"); }
    })();
  }, [loaded, online]);
  useEffect(() => {
    if (!loaded || !online || !cloudReady || !cloudUser) return;
    setCloudStatus("क्लाउड में सेव हो रहा है");
    const timer = window.setTimeout(() => {
      void fetch("/api/inventory", { method: "POST", credentials: "include", headers: { "content-type": "application/json" }, body: JSON.stringify({ snapshot: { products, sales, contacts, purchases }, audit: deletedRecords }) })
        .then(response => { if (!response.ok) throw new Error("sync failed"); setCloudStatus("क्लाउड सिंक सक्रिय"); })
        .catch(() => setCloudStatus("क्लाउड सिंक लंबित — फिर कोशिश होगी"));
    }, 700);
    return () => window.clearTimeout(timer);
  }, [products, sales, contacts, purchases, deletedRecords, loaded, online, cloudReady, cloudUser]);
  const filteredProducts = useMemo(() => products.filter(p => `${p.name} ${p.sku} ${p.category}`.toLowerCase().includes(search.toLowerCase())), [products, search]);
  const filteredSales = useMemo(() => sales.filter(s => `${s.invoice} ${s.customer}`.toLowerCase().includes(search.toLowerCase())), [sales, search]);
  const stockValue = products.reduce((sum, p) => sum + p.qty * p.cost, 0);
  const lowStock = products.filter(p => p.qty <= p.reorder).length;
  const activeSales = sales.filter(s => s.status !== "रद्द");
  const todaySales = activeSales.filter(s => s.date.startsWith("आज")).reduce((sum, s) => sum + s.amount, 0);
  const pageTitle: Record<Section, string> = { dashboard: "डैशबोर्ड", products: "स्टॉक और सामान", sales: "बिक्री और बिलिंग", purchases: "खरीद रिकॉर्ड", customers: "ग्राहक", suppliers: "सप्लायर", reports: "रिपोर्ट और हिसाब", settings: "सेटिंग्स" };
  const navGroups: { title: string; items: { id: Section; label: string; icon: string }[] }[] = [
    { title: "वर्कस्पेस", items: [{ id: "dashboard", label: "डैशबोर्ड", icon: "◫" }, { id: "products", label: "स्टॉक और सामान", icon: "▤" }, { id: "sales", label: "बिक्री और बिलिंग", icon: "↗" }, { id: "purchases", label: "खरीद रिकॉर्ड", icon: "↙" }] },
    { title: "संपर्क", items: [{ id: "customers", label: "ग्राहक", icon: "♙" }, { id: "suppliers", label: "सप्लायर", icon: "♧" }] },
    { title: "विश्लेषण", items: [{ id: "reports", label: "रिपोर्ट और हिसाब", icon: "▥" }, { id: "settings", label: "सेटिंग्स", icon: "⚙" }] },
  ];
  function appendDeletionRecord(recordType: string, recordId: string, recordName: string, recordData: unknown, reason: string) {
    const record: DeletionRecord = { id: crypto.randomUUID?.() ?? `${Date.now()}-${recordId}`, recordType, recordId, recordName, reason, deletedAt: new Date().toISOString(), source: online && cloudReady ? "online" : "offline", recordData };
    let current: DeletionRecord[] = [];
    try { current = JSON.parse(localStorage.getItem("ims-deleted-v1") || "[]") as DeletionRecord[]; } catch {}
    const next = [record, ...current];
    try { localStorage.setItem("ims-deleted-v1", JSON.stringify(next)); } catch {}
    setDeletedRecords(next);
  }
  function createAccountForCloud() { setAccountError(""); setAccountMode("register"); setAccountForm({ name: "", email: "", password: "" }); setModal("account"); }
  async function submitAccount(e: React.FormEvent) {
    e.preventDefault(); setAccountBusy(true); setAccountError("");
    try {
      const response = await fetch("/api/account", { method: "POST", credentials: "include", headers: { "content-type": "application/json" }, body: JSON.stringify({ action: accountMode === "register" ? "register" : "login", name: accountForm.name, email: accountForm.email, password: accountForm.password }) });
      const result = await response.json() as { user?: Record<string, unknown>; message?: string };
      if (!response.ok) { setAccountError(result.message || "अकाउंट प्रक्रिया पूरी नहीं हुई।"); return; }
      setModal(null); setCloudStatus("क्लाउड सिंक शुरू हो रहा है"); window.location.reload();
    } catch { setAccountError("सर्वर से कनेक्शन नहीं हुआ। इंटरनेट जाँचकर फिर कोशिश करें।"); }
    finally { setAccountBusy(false); }
  }
  async function signOutFromCloud() {
    try { await fetch("/api/account", { method: "POST", credentials: "include", headers: { "content-type": "application/json" }, body: JSON.stringify({ action: "logout" }) }); } finally { window.location.reload(); }
  }
  function addProduct(e: React.FormEvent) {
    e.preventDefault();
    if (!productForm.name.trim()) { setNotice("सामान का नाम भरें।"); return; }
    const item: Product = { id: crypto.randomUUID?.() ?? String(Date.now()), name: productForm.name.trim(), sku: productForm.sku.trim() || `ITM-${Date.now().toString().slice(-5)}`, category: productForm.category.trim() || "अन्य", qty: Math.max(0, Number(productForm.qty)), unit: productForm.unit, cost: Math.max(0, Number(productForm.cost)), price: Math.max(0, Number(productForm.price)), reorder: Math.max(0, Number(productForm.reorder)) };
    if (products.some(p => p.sku === item.sku)) { setNotice("यह आइटम कोड पहले से मौजूद है।"); return; }
    setProducts(prev => [item, ...prev]); setProductForm({ name: "", sku: "", category: "", qty: "0", unit: "पीस", cost: "0", price: "0", reorder: "5" }); setModal(null); setNotice("सामान सेव हो गया।");
  }
  function addSale(e: React.FormEvent) {
    e.preventDefault(); const p = products.find(x => x.id === saleForm.productId); const qty = Number(saleForm.qty);
    if (!p || qty <= 0) { setNotice("सामान और सही मात्रा चुनें।"); return; }
    if (qty > p.qty) { setNotice(`स्टॉक में केवल ${p.qty} ${p.unit} उपलब्ध है।`); return; }
    const sale: Sale = { id: crypto.randomUUID?.() ?? String(Date.now()), invoice: `INV-${Date.now().toString().slice(-6)}`, customer: saleForm.customer.trim() || "वॉक-इन ग्राहक", date: "आज, " + new Date().toLocaleTimeString("hi-IN", { hour: "2-digit", minute: "2-digit" }), amount: p.price * qty, method: saleForm.method, status: saleForm.method === "उधार" ? "बाकी" : "पूरा", productId: p.id, productName: p.name, qty, unit: p.unit };
    setProducts(prev => prev.map(x => x.id === p.id ? { ...x, qty: x.qty - qty } : x)); setSales(prev => [sale, ...prev]); setModal(null); setNotice(`बिक्री ${sale.invoice} सेव हुई। स्टॉक अपडेट किया गया।`);
  }
  function cancelSale(sale: Sale) {
    if (sale.status === "रद्द") { setNotice(`${sale.invoice} पहले से रद्द है; रिकॉर्ड सुरक्षित रखा गया है।`); return; }
    const reason = window.prompt(`${sale.invoice} रद्द करने का कारण लिखें (यह रिकॉर्ड में सुरक्षित रहेगा):`)?.trim();
    if (!reason) { setNotice("रद्द करने का कारण नहीं दिया गया; बिल रद्द नहीं किया गया।"); return; }
    if (!window.confirm(`${sale.invoice} को रद्द करें? बिल मिटेगा नहीं; रद्द रिकॉर्ड में सुरक्षित रहेगा।`)) return;
    if (sale.productId && sale.qty) setProducts(prev => prev.map(p => p.id === sale.productId ? { ...p, qty: p.qty + sale.qty! } : p));
    setSales(prev => prev.map(s => s.id === sale.id ? { ...s, status: "रद्द", cancelReason: reason, cancelledAt: new Date().toLocaleString("hi-IN") } : s));
    setNotice(`${sale.invoice} रद्द हुआ। रद्द करने का कारण और समय रिकॉर्ड में सुरक्षित है${sale.productId && sale.qty ? "; स्टॉक वापस जोड़ दिया गया।" : "। पुराने बिल में आइटम विवरण न होने से स्टॉक अपने-आप नहीं बदला।"}`);
  }
  function printReceipt(sale: Sale) {
    const popup = window.open("", "_blank", "width=420,height=700");
    if (!popup) { setNotice("रसीद प्रिंट करने के लिए पॉप-अप की अनुमति दें।"); return; }
    const esc = (v: unknown) => String(v ?? "—").replace(/[&<>\"']/g, ch => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", "\"": "&quot;", "'": "&#39;" }[ch] || ch));
    popup.document.write(`<!doctype html><html lang="hi"><head><meta charset="utf-8"><title>बिक्री रसीद ${esc(sale.invoice)}</title><style>body{font-family:Arial,sans-serif;padding:24px;color:#111;max-width:360px;margin:auto}h2,p{text-align:center;margin:5px 0}.muted{color:#555;font-size:12px}.line{border-top:1px dashed #555;margin:14px 0}table{width:100%;border-collapse:collapse;font-size:13px}td{padding:7px 0}td:last-child{text-align:right}.total{font-size:18px;font-weight:bold}.status{padding:8px;background:#f1f1f1;text-align:center;margin-top:12px}@media print{button{display:none}}</style></head><body><h2>बिक्री रसीद</h2><p class="muted">Inventory+ Stock & Sales Manager</p><div class="line"></div><p style="text-align:left"><b>बिल:</b> ${esc(sale.invoice)}<br><b>तारीख:</b> ${esc(sale.date)}<br><b>ग्राहक:</b> ${esc(sale.customer)}<br><b>भुगतान:</b> ${esc(sale.method)}</p><div class="line"></div><table><tr><td>सामान</td><td>${esc(sale.productName || "पुराना बिल")}</td></tr><tr><td>मात्रा</td><td>${sale.qty == null ? "—" : esc(`${sale.qty} ${sale.unit || ""}`)}</td></tr><tr><td>कुल राशि</td><td class="total">${esc(money(sale.amount))}</td></tr></table><div class="status">स्थिति: ${esc(sale.status)}</div>${sale.status === "रद्द" ? `<p style="text-align:left;font-size:12px">रद्द समय: ${esc(sale.cancelledAt)}<br>कारण: ${esc(sale.cancelReason)}</p>` : ""}<div class="line"></div><p class="muted">खरीदारी के लिए धन्यवाद!</p><script>window.onload=()=>window.print()<\/script></body></html>`);
    popup.document.close();
  }
  function addPurchase(e: React.FormEvent) {
    e.preventDefault();
    const p = products.find(x => x.id === purchaseForm.productId);
    const qty = Number(purchaseForm.qty), cost = Number(purchaseForm.cost);
    if (!p || qty <= 0 || cost < 0) { setNotice("सामान, सही मात्रा और खरीद मूल्य चुनें।"); return; }
    setProducts(prev => prev.map(x => x.id === p.id ? { ...x, qty: x.qty + qty, cost } : x));
    setPurchases(prev => [{ id: crypto.randomUUID?.() ?? String(Date.now()), product: p.name, qty, unit: p.unit, supplier: purchaseForm.supplier.trim() || "—", cost, total: qty * cost, date: new Date().toLocaleString("hi-IN") }, ...prev]);
    if (purchaseForm.supplier.trim() && !contacts.some(c => c.name.toLowerCase() === purchaseForm.supplier.trim().toLowerCase() && c.kind === "सप्लायर")) setContacts(prev => [{ id: crypto.randomUUID?.() ?? String(Date.now()), name: purchaseForm.supplier.trim(), phone: "", kind: "सप्लायर" }, ...prev]);
    setModal(null); setNotice(`${p.name} की खरीद दर्ज हुई; स्टॉक ${qty} ${p.unit} बढ़ा।`);
    setPurchaseForm({ productId: "", qty: "1", supplier: "", cost: "0" });
  }
  function removeProduct(id: string) {
    const p = products.find(x => x.id === id); if (!p) return;
    if (!window.confirm(`क्या आप “${p.name}” को हटाना चाहते हैं?`)) return;
    appendDeletionRecord("स्टॉक आइटम", p.id, p.name, p, "स्टॉक सूची से हटाया गया");
    setProducts(prev => prev.filter(x => x.id !== id));
    setSelectedProductIds(prev => prev.filter(selectedId => selectedId !== id));
    if (saleForm.productId === id) setSaleForm(prev => ({ ...prev, productId: products.find(x => x.id !== id)?.id || "" }));
    setNotice("आइटम सूची से हटा दिया गया।");
  }
  function toggleProductSelection(id: string) {
    setSelectedProductIds(prev => prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]);
  }
  function toggleAllVisibleProducts() {
    const visibleIds = filteredProducts.map(p => p.id);
    const allSelected = visibleIds.length > 0 && visibleIds.every(id => selectedProductIds.includes(id));
    setSelectedProductIds(prev => allSelected ? prev.filter(id => !visibleIds.includes(id)) : [...new Set([...prev, ...visibleIds])]);
  }
  function removeSelectedProducts() {
    const selected = products.filter(p => selectedProductIds.includes(p.id));
    if (!selected.length) { setNotice("पहले हटाने के लिए आइटम चुनें।"); return; }
    if (!window.confirm(`चुने गए ${selected.length} आइटम हटाएँ? यह कार्रवाई इस ब्राउज़र की स्टॉक सूची से उन्हें हटाएगी।`)) return;
    const ids = new Set(selected.map(p => p.id));
    selected.forEach(p => appendDeletionRecord("स्टॉक आइटम", p.id, p.name, p, "बल्क डिलीट"));
    setProducts(prev => prev.filter(p => !ids.has(p.id)));
    setSelectedProductIds([]);
    if (ids.has(saleForm.productId)) setSaleForm(prev => ({ ...prev, productId: products.find(p => !ids.has(p.id))?.id || "" }));
    setNotice(`${selected.length} चुने गए आइटम हटाए गए।`);
  }
  function addContact() {
    const name = window.prompt(`${section === "customers" ? "ग्राहक" : "सप्लायर"} का नाम लिखें:`)?.trim();
    if (!name) return;
    const phone = window.prompt("मोबाइल नंबर (वैकल्पिक):")?.trim() || "—";
    const kind = section === "customers" ? "ग्राहक" : "सप्लायर";
    setContacts(prev => [{ id: crypto.randomUUID?.() ?? String(Date.now()), name, phone, kind }, ...prev]);
    setNotice(`${kind} का रिकॉर्ड सेव हो गया।`);
  }
  function removeContact(id: string) {
    if (!window.confirm("क्या इस संपर्क को हटाना चाहते हैं?")) return;
    const contact = contacts.find(c => c.id === id);
    if (contact) appendDeletionRecord(contact.kind, contact.id, contact.name, contact, "संपर्क सूची से हटाया गया");
    setContacts(prev => prev.filter(c => c.id !== id));
  }
  function clearDemoAndStart() {
    if (!window.confirm("सभी मौजूदा स्टॉक और सक्रिय बिक्री रिकॉर्ड इस ब्राउज़र से हटेंगे। रद्द किए गए बिलों का रिकॉर्ड सुरक्षित रहेगा। पहले बैकअप लें। क्या जारी रखें?")) return;
    products.forEach(p => appendDeletionRecord("स्टॉक आइटम", p.id, p.name, p, "साफ शुरुआत के दौरान हटाया गया"));
    sales.filter(s => s.status !== "रद्द").forEach(s => appendDeletionRecord("बिक्री बिल", s.id, s.invoice, s, "साफ शुरुआत के दौरान हटाया गया"));
    purchases.forEach(b => appendDeletionRecord("खरीद रिकॉर्ड", b.id, b.product, b, "साफ शुरुआत के दौरान हटाया गया"));
    setProducts([]); setSales(prev => prev.filter(s => s.status === "रद्द")); setPurchases([]); localStorage.removeItem("ims-products-v1"); localStorage.removeItem("ims-purchases-v1");
    setNotice("स्टॉक और बिक्री खाली कर दिए गए। अब अपना असली स्टॉक जोड़ें।");
  }
  function backupData() {
    const blob = new Blob([JSON.stringify({ exportedAt: new Date().toISOString(), products, sales, contacts, purchases, deletedRecords }, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob); const a = document.createElement("a"); a.href = url; a.download = "inventory-plus-backup.json"; a.click(); URL.revokeObjectURL(url); setNotice("डेटा बैकअप डाउनलोड हो रहा है।");
  }
  async function installApp() {
    if (installPrompt) { await (installPrompt as any).prompt(); setInstallPrompt(null); }
    else setNotice("Chrome में ऊपर दाईं ओर ⋮ खोलें → Cast, save and share / Save and share → Install page as app या Create shortcut चुनें।");
  }
  function downloadStockTemplate() {
    const rows = [["SKU", "Product", "Category", "Quantity", "Unit", "Cost", "Price", "Reorder"], ["ITM-001", "A4 पेपर", "स्टेशनरी", "100", "रीम", "180", "220", "10"]];
    const csv = rows.map(row => row.map(v => `"${String(v).replaceAll('"', '""')}"`).join(",")).join("\r\n");
    const url = URL.createObjectURL(new Blob(["\ufeff" + csv], { type: "text/csv;charset=utf-8" }));
    const a = document.createElement("a"); a.href = url; a.download = "inventory-plus-stock-template.csv"; a.click(); URL.revokeObjectURL(url);
    setNotice("स्टॉक टेम्पलेट डाउनलोड हो गया। Excel में भरकर CSV UTF-8 के रूप में सेव करें।");
  }
  function parseCsv(text: string): string[][] {
    const rows: string[][] = []; let row: string[] = []; let cell = ""; let quoted = false;
    for (let i = 0; i < text.length; i++) {
      const ch = text[i];
      if (ch === '"' && quoted && text[i + 1] === '"') { cell += '"'; i++; }
      else if (ch === '"') quoted = !quoted;
      else if (ch === "," && !quoted) { row.push(cell.trim()); cell = ""; }
      else if ((ch === "\n" || ch === "\r") && !quoted) { if (ch === "\r" && text[i + 1] === "\n") i++; row.push(cell.trim()); if (row.some(v => v !== "")) rows.push(row); row = []; cell = ""; }
      else cell += ch;
    }
    row.push(cell.trim()); if (row.some(v => v !== "")) rows.push(row); return rows;
  }
  async function importStockFile(file?: File) {
    if (!file) return;
    if (!/\.(csv|txt)$/i.test(file.name)) { setImportSummary("यहाँ CSV फ़ाइल अपलोड करें। Excel में .xlsx फ़ाइल खोलें और Save As → CSV UTF-8 चुनकर फिर अपलोड करें।"); return; }
    try {
      const rows = parseCsv((await file.text()).replace(/^\uFEFF/, ""));
      if (rows.length < 2) { setImportSummary("फ़ाइल खाली है या उसमें डेटा की पंक्तियाँ नहीं हैं।"); return; }
      const norm = (v: string) => v.toLowerCase().replace(/[\s_()-]/g, "");
      const header = rows[0].map(norm);
      const findCol = (...names: string[]) => header.findIndex(h => names.includes(h));
      const cols = { sku: findCol("sku", "itemcode", "productcode", "आइटमकोड", "कोड"), name: findCol("product", "productname", "item", "itemname", "name", "सामान", "सामानकानाम", "नाम"), category: findCol("category", "कैटेगरी", "श्रेणी"), qty: findCol("quantity", "qty", "stock", "मात्रा", "स्टॉक"), unit: findCol("unit", "इकाई", "यूनिट"), cost: findCol("cost", "purchaseprice", "buyprice", "खरीदमूल्य"), price: findCol("price", "saleprice", "sellingprice", "बिक्रीमूल्य"), reorder: findCol("reorder", "reorderlevel", "lowstock", "कमस्टॉकसीमा") };
      if (cols.name < 0 || cols.qty < 0) { setImportSummary("शीर्षक पंक्ति में Product और Quantity कॉलम ज़रूरी हैं। पहले टेम्पलेट डाउनलोड करें।"); return; }
      const parsed: Product[] = []; let invalid = 0;
      for (const cells of rows.slice(1)) {
        const val = (idx: number, fallback = "") => idx < 0 ? fallback : (cells[idx] ?? fallback).trim();
        const name = val(cols.name), qty = Number(val(cols.qty, "0")), cost = Number(val(cols.cost, "0")), price = Number(val(cols.price, "0")), reorder = Number(val(cols.reorder, "5"));
        if (!name || !Number.isFinite(qty) || qty < 0 || !Number.isFinite(cost) || cost < 0 || !Number.isFinite(price) || price < 0 || !Number.isFinite(reorder) || reorder < 0) { invalid++; continue; }
        const sku = val(cols.sku) || `ITM-${Date.now().toString().slice(-5)}-${parsed.length + 1}`;
        if (parsed.some(p => p.sku === sku)) { invalid++; continue; }
        parsed.push({ id: crypto.randomUUID?.() ?? `${Date.now()}-${parsed.length}`, sku, name, category: val(cols.category, "अन्य") || "अन्य", qty, unit: val(cols.unit, "पीस") || "पीस", cost, price, reorder });
      }
      if (!parsed.length) { setImportSummary(`कोई मान्य पंक्ति नहीं मिली। छोड़ी गई पंक्तियाँ: ${invalid}।`); return; }
      const existingSkus = new Set(products.map(p => p.sku)); const additions = parsed.filter(p => !existingSkus.has(p.sku)); const duplicates = parsed.length - additions.length;
      if (!window.confirm(`${parsed.length} मान्य पंक्तियाँ मिलीं। ${additions.length} नए आइटम जुड़ेंगे, ${duplicates} पहले से मौजूद SKU छोड़े जाएँगे और ${invalid} गलत पंक्तियाँ छोड़ी गईं। जारी रखें?`)) return;
      setProducts(prev => [...additions, ...prev]);
      setImportSummary(`इम्पोर्ट पूरा: ${additions.length} नए आइटम जोड़े, ${duplicates} डुप्लिकेट और ${invalid} गलत पंक्तियाँ छोड़ीं।`);
      setNotice(`${additions.length} आइटम बल्क इम्पोर्ट हुए।`);
    } catch { setImportSummary("फ़ाइल पढ़ने में समस्या आई। कृपया Excel से CSV UTF-8 में दोबारा सेव करें।"); }
  }
  function exportCsv() {
    const rows = section === "sales" ? [["Invoice", "Customer", "Date", "Amount", "Payment", "Status"], ...sales.map(s => [s.invoice, s.customer, s.date, s.amount, s.method, s.status, s.cancelReason || "", s.cancelledAt || ""])] : [["SKU", "Product", "Category", "Quantity", "Unit", "Cost", "Price"], ...products.map(p => [p.sku, p.name, p.category, p.qty, p.unit, p.cost, p.price])];
    const csv = rows.map(row => row.map(v => `"${String(v).replaceAll('"', '""')}"`).join(",")).join("\r\n");
    const url = URL.createObjectURL(new Blob(["\ufeff" + csv], { type: "text/csv;charset=utf-8" })); const a = document.createElement("a"); a.href = url; a.download = section === "sales" ? "sales-report.csv" : "inventory-report.csv"; a.click(); URL.revokeObjectURL(url); setNotice("रिपोर्ट डाउनलोड शुरू हो गई।");
  }
  const currentProduct = products.find(p => p.id === saleForm.productId);
  if (!cloudUser) return <div className="ims-shell" style={{minHeight:"100vh",display:"grid",placeItems:"center",padding:24,background:"linear-gradient(135deg,#eef4ff 0%,#f8fafc 55%,#e9f8f1 100%)"}}>
    <section className="panel" style={{width:"min(100%,460px)",padding:32,borderRadius:24,boxShadow:"0 24px 70px rgba(28,48,90,.12)"}}>
      <div style={{display:"flex",alignItems:"center",gap:12,marginBottom:22}}><div style={{width:52,height:52,borderRadius:16,display:"grid",placeItems:"center",background:"#1d4ed8",color:"white",fontSize:25,fontWeight:800}}>I+</div><div><h1 style={{margin:0,fontSize:26}}>Inventory+</h1><p style={{margin:"4px 0 0",color:"#64748b"}}>स्टॉक और बिक्री प्रबंधन</p></div></div>
      <h2 style={{margin:"0 0 8px",fontSize:23}}>{accountMode === "register" ? "नया अकाउंट बनाएं" : "अपने अकाउंट में लॉगिन करें"}</h2>
      <p style={{margin:"0 0 22px",color:"#64748b",lineHeight:1.6}}>लॉगिन करने के बाद ही आपका स्टॉक, बिक्री और रिपोर्ट खुलेंगे। अपने अकाउंट से दूसरे कंप्यूटर पर भी डेटा इस्तेमाल करें।</p>
      <form onSubmit={submitAccount} className="form-grid">
        {accountError && <p className="wide" role="alert" style={{margin:0,color:"#b42318",background:"#fff1f0",padding:12,borderRadius:10}}>{accountError}</p>}
        {accountMode === "register" && <label className="wide">पूरा नाम<input required minLength={2} maxLength={100} autoComplete="name" value={accountForm.name} onChange={e=>setAccountForm({...accountForm,name:e.target.value})} placeholder="अपना नाम लिखें" /></label>}
        <label className="wide">ईमेल<input required type="email" maxLength={254} autoComplete="email" value={accountForm.email} onChange={e=>setAccountForm({...accountForm,email:e.target.value})} placeholder="name@example.com" /></label>
        <label className="wide">पासवर्ड<input required type="password" minLength={8} maxLength={128} autoComplete={accountMode === "register" ? "new-password" : "current-password"} value={accountForm.password} onChange={e=>setAccountForm({...accountForm,password:e.target.value})} placeholder="कम-से-कम 8 अक्षर" /></label>
        <div className="form-actions wide"><button type="submit" className="btn btn-primary" disabled={accountBusy}>{accountBusy ? "कृपया प्रतीक्षा करें…" : accountMode === "register" ? "अकाउंट बनाएं" : "लॉगिन करें"}</button></div>
        <p className="wide" style={{margin:0,textAlign:"center",fontSize:14}}>{accountMode === "register" ? "पहले से अकाउंट है? " : "पहली बार इस्तेमाल कर रहे हैं? "}<button type="button" className="text-link" onClick={()=>{setAccountError("");setAccountMode(accountMode === "register" ? "login" : "register");setAccountForm({name:"",email:accountForm.email,password:""});}}>{accountMode === "register" ? "लॉगिन करें" : "नया अकाउंट बनाएं"}</button></p>
        <p className="wide" style={{margin:0,fontSize:12,color:"#8a93a5",textAlign:"center"}}>आपका पासवर्ड सुरक्षित रूप से हैश करके सेव होता है।</p>
      </form>
    </section>
  </div>;
  return <div className="ims-shell">
    <aside className="sidebar">
      <div className="brand"><div className="brand-mark">in</div><div><strong>inventory<span>+</span></strong><small>STOCK & SALES</small></div></div>
      <div className="workspace-switch"><div className="workspace-avatar">B</div><div className="workspace-name"><strong>मेरा बिज़नेस</strong><small>मुख्य स्टोर</small></div><span className="chevron">⌄</span></div>
      {navGroups.map(group => <div className="nav-group" key={group.title}><p>{group.title}</p>{group.items.map(item => <button key={item.id} className={`nav-item ${section === item.id ? "active" : ""}`} onClick={() => { setSection(item.id); setSearch(""); }}><span className="nav-icon">{item.icon}</span>{item.label}{section === item.id && <span className="nav-active-dot" />}</button>)}</div>)}
      <div className="sidebar-bottom"><div className={`sync-card ${online ? "" : "offline"}`}><div className="sync-icon">{online ? "↻" : "⌁"}</div><div><strong>{online ? "ऑनलाइन" : "ऑफलाइन मोड"}</strong><small>{!online ? "ऑफलाइन बदलाव लोकल में सुरक्षित" : cloudUser ? cloudStatus : "क्लाउड के लिए साइन इन करें"}</small></div><span className="status-dot" /></div><div className="profile-row"><div className="profile-avatar">RP</div><div><strong>बिज़नेस एडमिन</strong><small>मालिक का अकाउंट</small></div><span className="more">···</span></div></div>
    </aside>
    <main className="main-area">
      <header className="topbar"><div className="breadcrumbs"><span>Workspace</span><b>/</b><strong>{pageTitle[section]}</strong></div><div className="topbar-actions">{!cloudUser && <><button className="btn btn-primary" onClick={() => { setAccountError(""); setAccountMode("login"); setAccountForm({ name: "", email: "", password: "" }); setModal("account"); }}>लॉगिन / Login</button><button className="btn btn-light" onClick={createAccountForCloud}>＋ अकाउंट बनाएं</button></>}{cloudUser && <><span className="stock-badge healthy">लॉगिन है</span><button className="btn btn-light" onClick={signOutFromCloud}>Logout</button></>}<button className="btn btn-light" onClick={installApp}>⇩ ऐप इंस्टॉल</button><div className={`connection-pill ${online ? "" : "offline"}`}><span />{online ? "ऑनलाइन" : "ऑफलाइन"}</div><button className="icon-button" aria-label="Notifications" onClick={() => setNotice("अभी कोई नई सूचना नहीं है।")}>♧<i /></button><div className="top-avatar">RP</div></div></header>
      <div className="page-content">
        <div className="page-heading"><div><p className="eyebrow">BUSINESS OVERVIEW</p><h1>{pageTitle[section]}</h1><p className="subheading">अपने स्टॉक, बिक्री और रोज़ के हिसाब पर नज़र रखें।</p></div><div className="heading-actions"><button className="btn btn-light" onClick={exportCsv}>⇩ रिपोर्ट डाउनलोड</button><button className="btn btn-primary" onClick={() => setModal("sale")}>＋ नई बिक्री</button></div></div>
        {notice && <div className="notice" role="status"><span>✓</span>{notice}<button onClick={() => setNotice("")} aria-label="Close notice">×</button></div>}
        {section === "dashboard" && <>
          <div className="welcome-strip"><div><div className="welcome-kicker"><span className="live-dot" /> आपका बिज़नेस, एक जगह</div><h2>आज का हिसाब साफ़ रखें।</h2><p>स्टॉक की स्थिति देखें, बिक्री दर्ज करें और अगला कदम तय करें।</p></div><div className="strip-art"><div className="art-ring ring-one"/><div className="art-ring ring-two"/><div className="art-box"><span>▥</span><small>STOCK</small><strong>+{products.length}</strong></div><div className="art-line"/></div></div>
          <div className="metrics-grid"><Metric label="आज की बिक्री" value={money(todaySales)} change={`${activeSales.filter(s => s.date.startsWith("आज")).length} सक्रिय बिल आज`} icon="↗" tone="blue"/><Metric label="कुल स्टॉक वैल्यू" value={money(stockValue)} change={`${products.length} सामान दर्ज`} icon="▤" tone="violet"/><Metric label="कम स्टॉक वाले आइटम" value={String(lowStock).padStart(2,"0")} change="रीऑर्डर की जाँच करें" icon="⚑" tone="amber"/><Metric label="बिक्री में बकाया" value={money(sales.filter(s=>s.status === "बाकी").reduce((a,s)=>a+s.amount,0))} change={`${sales.filter(s=>s.status === "बाकी").length} अधूरे भुगतान`} icon="◷" tone="green"/></div>
          <div className="content-grid"><section className="panel inventory-panel"><div className="panel-heading"><div><h3>स्टॉक पर नज़र</h3><p>कम मात्रा वाले सामान पहले देखें</p></div><button className="text-link" onClick={() => setSection("products")}>सभी सामान <span>↗</span></button></div><div className="stock-table"><div className="table-head"><span>सामान</span><span>मौजूदा स्टॉक</span><span>स्थिति</span></div>{products.slice().sort((a,b)=>(a.qty-a.reorder)-(b.qty-b.reorder)).slice(0,5).map(p=><div className="stock-row" key={p.id}><div className="product-cell"><div className={`product-icon icon-${p.category.length%4}`}>{p.name.slice(0,1)}</div><div><strong>{p.name}</strong><small>{p.sku} · {p.category}</small></div></div><div className="qty-cell"><strong>{p.qty} <small>{p.unit}</small></strong><div className="qty-track"><span style={{width:`${Math.min(100, p.qty/Math.max(p.reorder*3,1)*100)}%`}}/></div></div><div><span className={`stock-badge ${p.qty<=p.reorder?"low":"healthy"}`}>{p.qty<=p.reorder?"कम स्टॉक":"उपलब्ध"}</span></div></div>)}</div><button className="panel-footer-link" onClick={() => setModal("product")}>＋ नया सामान जोड़ें</button></section>
          <section className="panel quick-panel"><div className="panel-heading"><div><h3>जल्दी काम करें</h3><p>रोज़ के काम के शॉर्टकट</p></div><span className="sparkle">✳</span></div><div className="quick-actions"><button onClick={() => setModal("product")}><span className="quick-icon blue">＋</span><span><strong>सामान जोड़ें</strong><small>नया आइटम और उसकी कीमत दर्ज करें</small></span><b>↗</b></button><button onClick={() => setModal("sale")}><span className="quick-icon green">↗</span><span><strong>बिक्री दर्ज करें</strong><small>बिल बनाएँ और स्टॉक अपडेट करें</small></span><b>↗</b></button><button onClick={() => setModal("purchase")}><span className="quick-icon purple">↙</span><span><strong>खरीद दर्ज करें</strong><small>आया हुआ स्टॉक जोड़ें</small></span><b>↗</b></button><button onClick={() => setSection("reports")}><span className="quick-icon amber">▥</span><span><strong>रिपोर्ट देखें</strong><small>स्टॉक और बिक्री का हिसाब</small></span><b>↗</b></button></div></section></div>
          <section className="panel sales-panel"><div className="panel-heading"><div><h3>हाल की बिक्री</h3><p>आपके हाल के बिल और भुगतान</p></div><button className="text-link" onClick={() => setSection("sales")}>सभी बिक्री <span>↗</span></button></div><SalesTable sales={sales.slice(0,4)} onPrint={printReceipt} onCancel={cancelSale}/></section>
        </>}
        {section === "products" && <section className="panel full-panel"><div className="panel-heading"><div><h3>सामान की सूची</h3><p>{products.length} आइटम आपके स्टॉक में · {selectedProductIds.length} चुने गए</p></div><div className="stock-actions">{selectedProductIds.length>0&&<button className="btn btn-light delete-selected" onClick={removeSelectedProducts}>चुने हुए हटाएँ ({selectedProductIds.length})</button>}<button className="btn btn-light" onClick={downloadStockTemplate}>⇩ Excel टेम्पलेट</button><label className="btn btn-light file-upload-button">⇧ Excel/CSV बल्क इम्पोर्ट<input type="file" accept=".csv,.txt,text/csv" onChange={e=>{void importStockFile(e.target.files?.[0]);e.currentTarget.value="";}} /></label><button className="btn btn-primary" onClick={() => setModal("product")}>＋ सामान जोड़ें</button></div></div><p className="import-help">Excel में टेम्पलेट भरें, फिर <b>Save As → CSV UTF-8</b> करके यहाँ अपलोड करें। SKU पहले से मौजूद हो तो वह दोबारा नहीं जुड़ेगा।</p>{importSummary && <div className="import-summary" role="status">{importSummary}</div>}<SearchBox value={search} onChange={setSearch} placeholder="नाम, कोड या कैटेगरी से खोजें"/><div className="data-table"><div className="data-head product-data"><label className="select-stock-label"><input type="checkbox" aria-label="दिख रहे सभी आइटम चुनें" checked={filteredProducts.length>0&&filteredProducts.every(p=>selectedProductIds.includes(p.id))} onChange={toggleAllVisibleProducts}/> सभी चुनें</label><span>आइटम</span><span>कैटेगरी</span><span>मात्रा</span><span>खरीद मूल्य</span><span>बिक्री मूल्य</span><span>स्थिति</span><span>कार्रवाई</span></div>{filteredProducts.map(p=><div className="data-row product-data" key={p.id}><label className="select-stock-label"><input type="checkbox" aria-label={`${p.name} चुनें`} checked={selectedProductIds.includes(p.id)} onChange={()=>toggleProductSelection(p.id)}/></label><div className="product-cell"><div className="product-icon">{p.name.slice(0,1)}</div><div><strong>{p.name}</strong><small>{p.sku}</small></div></div><span>{p.category}</span><strong>{p.qty} {p.unit}</strong><span>{money(p.cost)}</span><span>{money(p.price)}</span><span className={`stock-badge ${p.qty<=p.reorder?"low":"healthy"}`}>{p.qty<=p.reorder?"कम स्टॉक":"उपलब्ध"}</span><button className="text-link" onClick={() => removeProduct(p.id)}>हटाएँ</button></div>)}</div>{filteredProducts.length===0&&<EmptyState text="इस खोज से कोई सामान नहीं मिला।"/>}</section>}
        {section === "sales" && <section className="panel full-panel"><div className="panel-heading"><div><h3>बिक्री और बिल</h3><p>बिक्री का रिकॉर्ड और भुगतान स्थिति</p></div><button className="btn btn-primary" onClick={() => setModal("sale")}>＋ नई बिक्री</button></div><SearchBox value={search} onChange={setSearch} placeholder="बिल नंबर या ग्राहक खोजें"/><SalesTable sales={filteredSales} onPrint={printReceipt} onCancel={cancelSale}/>{filteredSales.length===0&&<EmptyState text="कोई बिक्री रिकॉर्ड नहीं मिला।"/>}</section>}
        {section === "purchases" && <section className="panel full-panel"><div className="panel-heading"><div><h3>खरीद रिकॉर्ड</h3><p>खरीद दर्ज करें; मात्रा स्टॉक में जुड़ जाएगी।</p></div><button className="btn btn-primary" onClick={() => setModal("purchase")}>＋ खरीद दर्ज करें</button></div><div className="report-grid"><div className="panel report-card"><h3>कुल आइटम</h3><strong>{products.length}</strong></div><div className="panel report-card"><h3>स्टॉक वैल्यू</h3><strong>{money(stockValue)}</strong></div><div className="panel report-card"><h3>खरीद एंट्री</h3><strong>{purchases.length}</strong><button className="btn btn-light" onClick={() => setModal("purchase")}>खरीद जोड़ें</button></div></div><div className="data-table" style={{marginTop:20}}><div className="data-head purchase-data"><span>तारीख</span><span>सामान</span><span>मात्रा</span><span>सप्लायर</span><span>कुल राशि</span></div>{purchases.map(b=><div className="data-row purchase-data" key={b.id}><span>{b.date}</span><strong>{b.product}</strong><span>{b.qty} {b.unit}</span><span>{b.supplier}</span><strong>{money(b.total)}</strong></div>)}</div>{purchases.length===0&&<EmptyState text="अभी कोई खरीद दर्ज नहीं है।"/>}</section>}
        {(section === "customers" || section === "suppliers") && <section className="panel full-panel"><div className="panel-heading"><div><h3>{pageTitle[section]} सूची</h3><p>इस ब्राउज़र में सेव संपर्क: {contacts.filter(c => c.kind === (section === "customers" ? "ग्राहक" : "सप्लायर")).length}</p></div><button className="btn btn-primary" onClick={addContact}>＋ {section === "customers" ? "ग्राहक जोड़ें" : "सप्लायर जोड़ें"}</button></div><div className="data-table"><div className="data-head contact-data"><span>नाम</span><span>मोबाइल</span><span>प्रकार</span><span>कार्रवाई</span></div>{contacts.filter(c => c.kind === (section === "customers" ? "ग्राहक" : "सप्लायर")).map(c=><div className="data-row contact-data" key={c.id}><strong>{c.name}</strong><span>{c.phone || "—"}</span><span>{c.kind}</span><button className="text-link" onClick={() => removeContact(c.id)}>हटाएँ</button></div>)}</div>{!contacts.some(c => c.kind === (section === "customers" ? "ग्राहक" : "सप्लायर")) && <EmptyState text={`अभी कोई ${section === "customers" ? "ग्राहक" : "सप्लायर"} दर्ज नहीं है।`} />}</section>}
        {section === "reports" && <div className="report-grid"><div className="panel report-card"><span className="report-icon blue">▤</span><h3>स्टॉक रिपोर्ट</h3><p>मौजूदा मात्रा और खरीद मूल्य के आधार पर स्टॉक वैल्यू।</p><strong>{money(stockValue)}</strong><button className="btn btn-light" onClick={exportCsv}>CSV डाउनलोड करें</button></div><div className="panel report-card"><span className="report-icon green">↗</span><h3>बिक्री रिपोर्ट</h3><p>दर्ज बिलों की कुल बिक्री राशि।</p><strong>{money(activeSales.reduce((a,s)=>a+s.amount,0))}</strong><button className="btn btn-light" onClick={() => {setSection("sales");setSearch("")}}>बिक्री देखें</button></div><div className="panel report-card"><span className="report-icon amber">⚑</span><h3>कम स्टॉक रिपोर्ट</h3><p>वे सामान जिन्हें फिर से मँगाने की ज़रूरत हो सकती है।</p><strong>{lowStock} आइटम</strong><button className="btn btn-light" onClick={() => setSection("products")}>स्टॉक देखें</button></div></div>}
        {section === "settings" && <section className="panel settings-panel"><div className="panel-heading"><div><h3>बिज़नेस सेटिंग्स</h3><p>प्रारंभिक सेटअप और डेटा की स्थिति</p></div></div><div className="setting-row"><div><strong>ऑफलाइन सेविंग</strong><p>इस ब्राउज़र में सामान और बिक्री सेव होती है।</p></div><span className="stock-badge healthy">{loaded?"सक्रिय":"लोड हो रहा है"}</span></div><div className="setting-row"><div><strong>इंटरनेट कनेक्शन</strong><p>{online?"डिवाइस इंटरनेट से जुड़ा है।":"इंटरनेट नहीं है।"}</p></div><span className={`stock-badge ${online?"healthy":"low"}`}>{online?"ऑनलाइन":"ऑफलाइन"}</span></div><div className="setting-row"><div><strong>क्लाउड डेटाबेस और कई कंप्यूटर</strong><p>{cloudUser ? "आपका डेटा इस अकाउंट के क्लाउड डेटाबेस में सेव होगा और उसी अकाउंट से दूसरे कंप्यूटर पर भी उपलब्ध होगा। ऑफलाइन बदलाव पहले इसी डिवाइस पर सेव होते हैं और इंटरनेट लौटने पर सिंक होते हैं।" : "क्लाउड डेटा चालू करने के लिए अपने अकाउंट से साइन इन करें। ऑफलाइन में डेटा और हटाने का इतिहास इसी ब्राउज़र में सेव रहेगा।"}</p></div><div className="cloud-actions"><span className={`stock-badge ${cloudStatus === "क्लाउड सिंक सक्रिय" ? "healthy" : "low"}`}>{!online ? "ऑफलाइन लोकल सेव" : cloudStatus}</span>{!cloudUser && <div className="cloud-actions-buttons"><button className="btn btn-primary" onClick={() => { setAccountError(""); setAccountMode("login"); setAccountForm({ name: "", email: "", password: "" }); setModal("account"); }}>लॉगिन करें</button><button className="btn btn-light" onClick={createAccountForCloud}>अकाउंट बनाएं</button></div>}</div></div>
          <div className="setting-row deletion-history-row"><div><strong>हटाए गए डेटा का स्थायी रिकॉर्ड ({deletedRecords.length})</strong><p>स्टॉक, संपर्क, बिल या खरीद हटाने पर नाम, पुराना डेटा, कारण और समय रिकॉर्ड होता है। ऑफलाइन डिलीट भी पहले लोकल में सुरक्षित होता है और कनेक्शन मिलने पर क्लाउड में सिंक होता है। यह इतिहास सामान्य डिलीट से नहीं मिटेगा।</p></div><span className="stock-badge healthy">रिकॉर्ड सुरक्षित</span></div>
          {deletedRecords.length > 0 && <div className="deletion-history"><div className="deletion-history-head"><strong>हटाने का इतिहास</strong><span>नवीनतम 50 रिकॉर्ड</span></div>{deletedRecords.slice(0,50).map(record => <div className="deletion-history-item" key={record.id}><div><strong>{record.recordName}</strong><small>{record.recordType} · {record.reason}</small></div><div className="deletion-meta"><span>{new Date(record.deletedAt).toLocaleString("hi-IN")}</span><small>{record.source === "offline" ? "ऑफलाइन डिलीट" : "ऑनलाइन डिलीट"}</small></div></div>)}</div>}<div className="setting-row"><div><strong>डेटा एक्सपोर्ट</strong><p>स्टॉक और बिक्री की CSV फाइल डाउनलोड करें।</p></div><button className="btn btn-light" onClick={exportCsv}>CSV एक्सपोर्ट</button></div><div className="setting-row"><div><strong>पूरा बैकअप डाउनलोड</strong><p>स्टॉक और बिक्री का JSON बैकअप सुरक्षित रखें।</p></div><button className="btn btn-light" onClick={backupData}>बैकअप डाउनलोड</button></div><div className="setting-row"><div><strong>कंप्यूटर पर ऐप इंस्टॉल करें</strong><p>यह वेब ऐप है; इसे समर्थित ब्राउज़र से ऐप की तरह इंस्टॉल कर सकते हैं। अलग Windows .exe अभी उपलब्ध नहीं है।</p></div><button className="btn btn-primary" onClick={installApp}>ऐप इंस्टॉल</button></div><div className="setting-row"><div><strong>साफ शुरुआत</strong><p>मौजूदा स्टॉक और बिक्री रिकॉर्ड हटाएँ। कार्रवाई से पहले पुष्टि माँगी जाएगी।</p></div><button className="btn btn-light" onClick={clearDemoAndStart}>स्टॉक/बिक्री हटाएँ</button></div></section>}
        <footer className="page-footer"><span>Inventory+ <b>•</b> स्टॉक और बिक्री प्रबंधन</span><span><i className={`footer-dot ${online?"":"offline"}`}/>{online ? cloudStatus : "ऑफलाइन लोकल सेव"} <b>·</b> हटाने का इतिहास सुरक्षित</span></footer>
      </div>
    </main>
    {modal && <div className="modal-backdrop" role="presentation" onMouseDown={e => { if(e.target===e.currentTarget) setModal(null); }}><div className="modal" role="dialog" aria-modal="true" aria-labelledby="modal-title"><div className="modal-heading"><div><p className="eyebrow">{modal === "account" ? "INVENTORY+ ACCOUNT" : "QUICK ENTRY"}</p><h2 id="modal-title">{modal==="account"?"लॉगिन या नया अकाउंट":modal==="product"?"नया सामान जोड़ें":modal==="sale"?"नई बिक्री दर्ज करें":"खरीद दर्ज करें"}</h2></div><button className="close-button" onClick={() => setModal(null)} aria-label="Close">×</button></div>
      {modal === "account" && <form onSubmit={submitAccount} className="form-grid">{accountError && <p className="wide" role="alert" style={{margin:0,color:"#b42318",background:"#fff1f0",padding:12,borderRadius:10}}>{accountError}</p>}<p className="wide" style={{margin:0,color:"#586174",lineHeight:1.6}}>{accountMode === "register" ? "अपना Inventory+ अकाउंट बनाएं। आपका डेटा इस अकाउंट के साथ क्लाउड में सेव होगा।" : "अपने Inventory+ अकाउंट में लॉगिन करें और अपना सेव किया हुआ डेटा खोलें।"}</p>{accountMode === "register" && <label className="wide">पूरा नाम<input required minLength={2} maxLength={100} autoComplete="name" value={accountForm.name} onChange={e=>setAccountForm({...accountForm,name:e.target.value})} placeholder="अपना नाम लिखें" /></label>}<label className="wide">ईमेल<input required type="email" maxLength={254} autoComplete="email" value={accountForm.email} onChange={e=>setAccountForm({...accountForm,email:e.target.value})} placeholder="name@example.com" /></label><label className="wide">पासवर्ड<input required type="password" minLength={8} maxLength={128} autoComplete={accountMode === "register" ? "new-password" : "current-password"} value={accountForm.password} onChange={e=>setAccountForm({...accountForm,password:e.target.value})} placeholder="कम-से-कम 8 अक्षर" /></label><div className="form-actions wide"><button type="button" className="btn btn-light" onClick={()=>setModal(null)}>रद्द करें</button><button type="submit" className="btn btn-primary" disabled={accountBusy}>{accountBusy ? "कृपया प्रतीक्षा करें…" : accountMode === "register" ? "अकाउंट बनाएं" : "लॉगिन करें"}</button></div><p className="wide" style={{margin:0,fontSize:13}}>{accountMode === "register" ? "पहले से अकाउंट है? " : "नया अकाउंट चाहिए? "}<button type="button" className="text-link" onClick={()=>{setAccountMode(accountMode === "register" ? "login" : "register");setAccountForm({name:"",email:accountForm.email,password:""});}}>{accountMode === "register" ? "लॉगिन करें" : "अकाउंट बनाएं"}</button></p><p className="wide" style={{margin:0,fontSize:12,color:"#8a93a5"}}>पासवर्ड सुरक्षित रूप से हैश करके सेव होता है; मूल पासवर्ड डेटाबेस में नहीं रखा जाता।</p></form>}
      {modal==="product"&&<form onSubmit={addProduct} className="form-grid"><label className="wide">सामान का नाम<input required value={productForm.name} onChange={e=>setProductForm({...productForm,name:e.target.value})} placeholder="जैसे A4 पेपर"/></label><label>आइटम कोड<input value={productForm.sku} onChange={e=>setProductForm({...productForm,sku:e.target.value})} placeholder="ऑटो बनेगा"/></label><label>कैटेगरी<input value={productForm.category} onChange={e=>setProductForm({...productForm,category:e.target.value})} placeholder="जैसे स्टेशनरी"/></label><label>शुरुआती मात्रा<input type="number" min="0" step="any" value={productForm.qty} onChange={e=>setProductForm({...productForm,qty:e.target.value})}/></label><label>यूनिट<select value={productForm.unit} onChange={e=>setProductForm({...productForm,unit:e.target.value})}><option>पीस</option><option>किलो</option><option>लीटर</option><option>पैक</option><option>डिब्बा</option><option>रीम</option><option>रोल</option></select></label><label>खरीद मूल्य (₹)<input type="number" min="0" step="any" value={productForm.cost} onChange={e=>setProductForm({...productForm,cost:e.target.value})}/></label><label>बिक्री मूल्य (₹)<input type="number" min="0" step="any" value={productForm.price} onChange={e=>setProductForm({...productForm,price:e.target.value})}/></label><label>कम स्टॉक सीमा<input type="number" min="0" step="any" value={productForm.reorder} onChange={e=>setProductForm({...productForm,reorder:e.target.value})}/></label><div className="form-actions wide"><button type="button" className="btn btn-light" onClick={()=>setModal(null)}>रद्द करें</button><button type="submit" className="btn btn-primary">सामान सेव करें</button></div></form>}
      {modal==="sale"&&<form onSubmit={addSale} className="form-grid"><label className="wide">ग्राहक का नाम<input value={saleForm.customer} onChange={e=>setSaleForm({...saleForm,customer:e.target.value})} placeholder="वॉक-इन ग्राहक के लिए खाली छोड़ें"/></label><label className="wide">सामान चुनें<select required value={saleForm.productId} onChange={e=>setSaleForm({...saleForm,productId:e.target.value})}><option value="">सामान चुनें</option>{products.map(p=><option key={p.id} value={p.id}>{p.name} · उपलब्ध {p.qty} {p.unit} · {money(p.price)}</option>)}</select></label><label>मात्रा<input type="number" min="0.01" step="any" value={saleForm.qty} onChange={e=>setSaleForm({...saleForm,qty:e.target.value})}/></label><label>भुगतान का तरीका<select value={saleForm.method} onChange={e=>setSaleForm({...saleForm,method:e.target.value})}><option>UPI</option><option>नकद</option><option>बैंक</option><option>उधार</option></select></label><div className="sale-total wide"><span>बिल की कुल राशि</span><strong>{money((currentProduct?.price||0)*Math.max(0,Number(saleForm.qty)))}</strong><small>बिक्री सेव होने पर स्टॉक अपने-आप घटेगा।</small></div><div className="form-actions wide"><button type="button" className="btn btn-light" onClick={()=>setModal(null)}>रद्द करें</button><button type="submit" className="btn btn-primary" disabled={products.length===0}>बिक्री सेव करें</button></div></form>}
      {modal==="purchase"&&<form onSubmit={addPurchase} className="form-grid"><label className="wide">सामान चुनें<select required value={purchaseForm.productId} onChange={e=>{const p=products.find(x=>x.id===e.target.value);setPurchaseForm({...purchaseForm,productId:e.target.value,cost:String(p?.cost??0)});}}><option value="">सामान चुनें</option>{products.map(p=><option key={p.id} value={p.id}>{p.name} · मौजूदा {p.qty} {p.unit}</option>)}</select></label><label>खरीदी गई मात्रा<input required type="number" min="0.01" step="any" value={purchaseForm.qty} onChange={e=>setPurchaseForm({...purchaseForm,qty:e.target.value})}/></label><label>प्रति यूनिट खरीद मूल्य (₹)<input required type="number" min="0" step="any" value={purchaseForm.cost} onChange={e=>setPurchaseForm({...purchaseForm,cost:e.target.value})}/></label><label className="wide">सप्लायर का नाम<input value={purchaseForm.supplier} onChange={e=>setPurchaseForm({...purchaseForm,supplier:e.target.value})} placeholder="वैकल्पिक"/></label><div className="sale-total wide"><span>खरीद की कुल राशि</span><strong>{money(Number(purchaseForm.qty)*Number(purchaseForm.cost))}</strong><small>सेव करने पर चुने हुए सामान का स्टॉक बढ़ेगा।</small></div><div className="form-actions wide"><button type="button" className="btn btn-light" onClick={()=>setModal(null)}>रद्द करें</button><button type="submit" className="btn btn-primary" disabled={!products.length}>खरीद सेव करें</button></div></form>}
    </div></div>}
  </div>;
}
function Metric({label,value,change,icon,tone}:{label:string;value:string;change:string;icon:string;tone:string}){return <div className="metric-card"><div className="metric-top"><span>{label}</span><span className={`metric-icon ${tone}`}>{icon}</span></div><strong className="metric-value">{value}</strong><div className="metric-change"><span className={`mini-mark ${tone}`}>↗</span>{change}</div></div>}
function SearchBox({value,onChange,placeholder}:{value:string;onChange:(v:string)=>void;placeholder:string}){return <div className="search-box"><span>⌕</span><input value={value} onChange={e=>onChange(e.target.value)} placeholder={placeholder}/><kbd>⌘ K</kbd></div>}
function SalesTable({sales,onPrint,onCancel}:{sales:Sale[];onPrint:(sale:Sale)=>void;onCancel:(sale:Sale)=>void}){return <div className="sales-table"><div className="sales-head"><span>बिल नंबर</span><span>ग्राहक</span><span>समय</span><span>भुगतान</span><span>राशि</span><span>स्थिति / कार्रवाई</span></div>{sales.map(s=><div className="sales-row" key={s.id}><strong className="invoice">{s.invoice}</strong><span>{s.customer}{s.status==="रद्द"&&<small className="cancel-detail">रद्द: {s.cancelReason || "कारण दर्ज नहीं"} · {s.cancelledAt || "समय उपलब्ध नहीं"}</small>}</span><span className="muted-cell">{s.date}</span><span><span className="method-pill">{s.method}</span></span><strong className="amount-cell">{money(s.amount)}</strong><span className="sale-actions"><span className={`stock-badge ${s.status==="पूरा"?"healthy":s.status==="रद्द"?"low":"low"}`}>{s.status}</span><button className="text-link" onClick={()=>onPrint(s)}>प्रिंट</button>{s.status!=="रद्द"&&<button className="text-link cancel-link" onClick={()=>onCancel(s)}>रद्द करें</button>}</span></div>)}</div>}
function EmptyState({text}:{text:string}){return <div className="empty-state"><span>⌕</span><strong>{text}</strong><small>खोज बदलकर फिर प्रयास करें।</small></div>}
