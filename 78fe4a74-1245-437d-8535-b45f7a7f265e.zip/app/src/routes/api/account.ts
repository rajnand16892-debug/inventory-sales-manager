import { createFileRoute } from '@tanstack/react-router'
import { bindings } from '@/lib/bindings.server'
import { createSession, currentAppUser, loginAccount, registerAccount, revokeSession, sessionCookie } from '@/lib/app-auth.server'

const noStore = { 'cache-control': 'no-store' }
export const Route = createFileRoute('/api/account')({
  server: { handlers: {
    GET: async ({ request }) => {
      const user = await currentAppUser(request)
      return Response.json({ user }, { headers: noStore })
    },
    POST: async ({ request }) => {
      if (!bindings().DB) return Response.json({ error: 'database_unavailable', message: 'अकाउंट डेटाबेस अभी उपलब्ध नहीं है।' }, { status: 503, headers: noStore })
      let body: Record<string, unknown>
      try { body = await request.json() as Record<string, unknown> } catch { return Response.json({ error: 'invalid_json' }, { status: 400, headers: noStore }) }
      const action = body.action
      if (action === 'logout') {
        try { await revokeSession(request) } catch {}
        return Response.json({ ok: true }, { headers: { ...noStore, 'set-cookie': sessionCookie('', 0) } })
      }
      const email = typeof body.email === 'string' ? body.email.trim().toLowerCase() : ''
      const password = typeof body.password === 'string' ? body.password : ''
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || email.length > 254 || password.length < 8 || password.length > 128) {
        return Response.json({ error: 'invalid_input', message: 'सही ईमेल और कम-से-कम 8 अक्षर का पासवर्ड भरें।' }, { status: 400, headers: noStore })
      }
      try {
        let user
        if (action === 'register') {
          const name = typeof body.name === 'string' ? body.name.trim() : ''
          if (name.length < 2 || name.length > 100) return Response.json({ error: 'invalid_name', message: 'अपना नाम भरें (कम-से-कम 2 अक्षर)।' }, { status: 400, headers: noStore })
          user = await registerAccount(name, email, password)
        } else if (action === 'login') {
          user = await loginAccount(email, password)
          if (!user) return Response.json({ error: 'invalid_credentials', message: 'ईमेल या पासवर्ड सही नहीं है।' }, { status: 401, headers: noStore })
        } else return Response.json({ error: 'invalid_action' }, { status: 400, headers: noStore })
        const token = await createSession(user.id)
        return Response.json({ user }, { headers: { ...noStore, 'set-cookie': sessionCookie(token) } })
      } catch (error) {
        const message = error instanceof Error ? error.message : ''
        if (message.includes('UNIQUE constraint failed')) return Response.json({ error: 'email_exists', message: 'इस ईमेल से पहले ही अकाउंट बना हुआ है। लॉगिन करें।' }, { status: 409, headers: noStore })
        return Response.json({ error: 'account_operation_failed', message: 'अकाउंट प्रक्रिया पूरी नहीं हो सकी। थोड़ी देर बाद फिर कोशिश करें।' }, { status: 500, headers: noStore })
      }
    },
  } },
})
