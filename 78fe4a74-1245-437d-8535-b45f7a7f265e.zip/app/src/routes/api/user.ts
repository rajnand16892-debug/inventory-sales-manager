import { createFileRoute } from '@tanstack/react-router'
import { currentAppUser } from '@/lib/app-auth.server'

export const Route = createFileRoute('/api/user')({
  server: { handlers: {
    GET: async ({ request }) => {
      const user = await currentAppUser(request)
      if (!user) return Response.json({ error: 'unauthorized' }, { status: 401, headers: { 'cache-control': 'no-store' } })
      return Response.json(user, { headers: { 'cache-control': 'no-store' } })
    },
  } },
})
