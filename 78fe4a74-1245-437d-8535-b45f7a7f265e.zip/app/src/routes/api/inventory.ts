import { createFileRoute } from '@tanstack/react-router'
import { bindings } from '@/lib/bindings.server'
import { currentAppUser } from '@/lib/app-auth.server'

type AuditInput = {
  id: string
  recordType: string
  recordId: string
  recordName: string
  reason?: string
  deletedAt: string
  source?: string
  recordData: unknown
}

async function currentUserId(request: Request): Promise<string | null> {
  const user = await currentAppUser(request)
  return user?.id ?? null
}

function validSnapshot(value: unknown): value is { products: unknown[]; sales: unknown[]; contacts: unknown[]; purchases: unknown[] } {
  if (!value || typeof value !== 'object') return false
  const item = value as Record<string, unknown>
  return ['products', 'sales', 'contacts', 'purchases'].every(key => Array.isArray(item[key]) && (item[key] as unknown[]).length <= 20000)
}

export const Route = createFileRoute('/api/inventory')({
  server: {
    handlers: {
      GET: async ({ request }) => {
        const userId = await currentUserId(request)
        if (!userId) return Response.json({ error: 'unauthorized' }, { status: 401, headers: { 'cache-control': 'no-store' } })
        const db = bindings().DB
        if (!db) return Response.json({ error: 'database_unavailable' }, { status: 503, headers: { 'cache-control': 'no-store' } })
        try {
          const snapshot = await db.prepare('SELECT snapshot_json, updated_at FROM inventory_snapshots WHERE user_id = ?').bind(userId).first<{ snapshot_json: string; updated_at: string }>()
          const audit = await db.prepare('SELECT id, record_type, record_id, record_name, reason, deleted_at, source, record_json FROM inventory_deletion_audit WHERE user_id = ? ORDER BY deleted_at DESC LIMIT 5000').bind(userId).all<{ id: string; record_type: string; record_id: string; record_name: string; reason: string; deleted_at: string; source: string; record_json: string }>()
          const records = (audit.results ?? []).map(row => ({ id: row.id, recordType: row.record_type, recordId: row.record_id, recordName: row.record_name, reason: row.reason, deletedAt: row.deleted_at, source: row.source, recordData: safeJson(row.record_json) }))
          return Response.json({ snapshot: snapshot ? safeJson(snapshot.snapshot_json) : null, updatedAt: snapshot?.updated_at ?? null, audit: records }, { headers: { 'cache-control': 'no-store' } })
        } catch {
          return Response.json({ error: 'cloud_read_failed' }, { status: 500, headers: { 'cache-control': 'no-store' } })
        }
      },
      POST: async ({ request }) => {
        const userId = await currentUserId(request)
        if (!userId) return Response.json({ error: 'unauthorized' }, { status: 401, headers: { 'cache-control': 'no-store' } })
        const db = bindings().DB
        if (!db) return Response.json({ error: 'database_unavailable' }, { status: 503, headers: { 'cache-control': 'no-store' } })
        const length = Number(request.headers.get('content-length') ?? 0)
        if (length > 2_000_000) return Response.json({ error: 'payload_too_large' }, { status: 413, headers: { 'cache-control': 'no-store' } })
        let body: unknown
        try {
          const rawBody = await request.text()
          if (rawBody.length > 2_000_000) return Response.json({ error: 'payload_too_large' }, { status: 413, headers: { 'cache-control': 'no-store' } })
          body = JSON.parse(rawBody) as unknown
        } catch { return Response.json({ error: 'invalid_json' }, { status: 400 }) }
        if (!body || typeof body !== 'object') return Response.json({ error: 'invalid_payload' }, { status: 400 })
        const payload = body as Record<string, unknown>
        if (!validSnapshot(payload.snapshot)) return Response.json({ error: 'invalid_snapshot' }, { status: 400 })
        const snapshotJson = JSON.stringify(payload.snapshot)
        if (snapshotJson.length > 1_500_000) return Response.json({ error: 'snapshot_too_large' }, { status: 413 })
        const audit = Array.isArray(payload.audit) ? payload.audit.slice(0, 5000) as AuditInput[] : []
        const statements = [db.prepare('INSERT INTO inventory_snapshots (user_id, snapshot_json, updated_at) VALUES (?, ?, CURRENT_TIMESTAMP) ON CONFLICT(user_id) DO UPDATE SET snapshot_json = excluded.snapshot_json, updated_at = CURRENT_TIMESTAMP').bind(userId, snapshotJson)]
        for (const row of audit) {
          if (!row || typeof row.id !== 'string' || row.id.length > 100 || typeof row.recordType !== 'string' || row.recordType.length > 40 || typeof row.recordId !== 'string' || row.recordId.length > 120 || typeof row.recordName !== 'string' || row.recordName.length > 300 || typeof row.deletedAt !== 'string') continue
          const recordJson = JSON.stringify(row.recordData ?? null)
          if (recordJson.length > 20000) continue
          statements.push(db.prepare('INSERT OR IGNORE INTO inventory_deletion_audit (id, user_id, record_type, record_id, record_name, reason, deleted_at, source, record_json) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)').bind(row.id, userId, row.recordType, row.recordId, row.recordName, typeof row.reason === 'string' ? row.reason.slice(0, 500) : '', row.deletedAt.slice(0, 80), row.source === 'online' ? 'online' : 'offline', recordJson))
        }
        try {
          await db.batch(statements)
          return Response.json({ ok: true, savedAt: new Date().toISOString(), auditCount: audit.length }, { headers: { 'cache-control': 'no-store' } })
        } catch {
          return Response.json({ error: 'cloud_write_failed' }, { status: 500, headers: { 'cache-control': 'no-store' } })
        }
      },
    },
  },
})

function safeJson(value: string): unknown {
  try { return JSON.parse(value) as unknown } catch { return null }
}
